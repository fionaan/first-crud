package com.fiona.springmongodb.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.fiona.springmongodb.models.Bread;

public interface BreadRepository extends MongoRepository<Bread, Integer>{

}
